import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_ffmpeg/flutter_ffmpeg.dart';
import 'package:matrix_gesture_detector/matrix_gesture_detector.dart';
import 'package:path_provider/path_provider.dart';
import 'package:svgonvideo/video.dart';
import 'package:vector_math/vector_math_64.dart' as vector;
import 'package:video_player/video_player.dart';
import 'constant/sticker_data.dart';
import 'constant/sticker_gif_data.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      showSemanticsDebugger: false,
      home: ChooseFile(),
    );
  }
}

class ChooseFile extends StatefulWidget {
  @override
  _ChooseFileState createState() => _ChooseFileState();
}

class _ChooseFileState extends State<ChooseFile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Center(
            child: Text(
          'Sticker Demo',
          style: TextStyle(color: Colors.white, fontSize: 18),
        )),
      ),
      body: Container(
        color: Colors.white,
        child: GestureDetector(
          onTap: () async {
            var result = await FilePicker.platform.pickFiles(type: FileType.video);
            if (result != null) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => TransformDemo2(result)));
            }
          },
          child: Center(
            child: Container(
              height: MediaQuery.of(context).size.height / 7,
              width: MediaQuery.of(context).size.width / 3,
              decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(12)), color: Colors.pink[700]),
              child: Center(
                  child: Text(
                'Choose Video',
                style: TextStyle(color: Colors.white),
              )),
            ),
          ),
        ),
      ),
    );
  }
}

class TransformDemo2 extends StatefulWidget {
  final result;

  TransformDemo2(this.result);

  @override
  _TransformDemo2State createState() => _TransformDemo2State();
}

class _TransformDemo2State extends State<TransformDemo2> {
  VideoPlayerController _controller;
  Matrix4 matrix;
  ValueNotifier<Matrix4> notifier;
  Boxer boxer;
  double _rotation = 0.0;
  Offset offset = Offset(0, 0);
  double _scale = 0.0;
  bool isCalled = false;
  GlobalKey sizeKey = GlobalKey();
  FlutterFFmpeg _flutterFFmpeg = new FlutterFFmpeg();
  List<ShareInfoModel> _listInfo = List(); //list of social data icons
  bool visibility = false;
  int selected = 0;
  String type = 'Stickers';
  bool loading = false;
  List<GifSticker> _gifListInfo = List(); //list of social data icons
  bool loadedVideo=false;
  @override
  void initState() {
    super.initState();

  }

  @override
  void didChangeDependencies() {
    if (!isCalled) fetchData();
    super.didChangeDependencies();
  }

  _loadFromAsset() async {
    var bytes;
    final filename = 'sticker' + DateTime.now().microsecondsSinceEpoch.toString() + 'torii.jpeg';
   if(type=='Stickers'){
     bytes = await rootBundle.load('assets/torii.jpeg');

   }
   else{
     bytes = await rootBundle.load(_gifListInfo[selected].asset);
   }
   final String dir =
        Platform.isAndroid ? (await getExternalStorageDirectory()).path : await getApplicationDocumentsDirectory();
   final path = '$dir/$filename';
   final buffer = bytes.buffer;
    print(path);
    await File(path).writeAsBytes(buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes));
    File file = File('$dir/$filename');
    print('Loaded file ${file.path}');
    return file.path;
  }

  Future<String> merge(BuildContext context) async {
    setState(() {
      loading = true;
    });
    var deviceAspectRatio = MediaQuery.of(context).devicePixelRatio;
    var videoAspectRatio = _controller.value.size.width;
    print('WidthOfDevice::${MediaQuery.of(context).size.width},,,VideoWidth::$videoAspectRatio');
    String videoPath = widget.result?.files.single.path;
    final filename = 'StickerOutput${DateTime.now().millisecondsSinceEpoch}_output.jpeg';
    Directory dir = Platform.isAndroid ? await getExternalStorageDirectory() : await getApplicationDocumentsDirectory();
    var ar = MediaQuery.of(context).size.aspectRatio;
    final imgpath = await _loadFromAsset();
    var localCommand;
    final outputPath = dir.path + "/" + filename;
    var ratio = (_controller.value.size.width / MediaQuery.of(context).size.width);
    var hratio = (_controller.value.size.height / MediaQuery.of(context).size.height);
    var wdata;
    var hdata;
    if(type=='Stickers'){
      wdata = 400 * (_scale) * ratio;
      hdata = 512 * (_scale) *hratio;
    }
    else{
      wdata = 212 * (_scale) * ratio;
    }
    var width=_controller.value.size.height;
    var height=width*2;
    //var hdata = MediaQuery.of(context).size.height/4;
    print('ratio::$ratio,,hratio::$hratio');
    //localCommand = "-i 'https://kapil-soni333.github.io/Video/captain.mp4' -stream_loop -1 -i '$imgpath'  -shortest -c:v copy -c:a aac -map 0:v:0 -map 1:a:0 -af apad '$outputPath'";
    //localCommand ="-i '$videoPath' -i '$imgpath' -vcodec libx264 -crf 35 -r 15 -preset ultrafast -threads 0 -filter_complex '[1:v]format=bgra,rotate=$_rotation:c=none:ow=rotw($_rotation):oh=roth($_rotation)[rotate];[rotate]scale=$wdata:-1[scale];[0:v][scale] overlay=x=${offset.dx * ratio}:y=${offset.dy * hratio}' -preset ultrafast -threads 0 '$outputPath'";
 // String localCommand="-i '$thumbnailurl' '$outputPath'";
    if(deviceAspectRatio<=videoAspectRatio){
      if (type == 'Stickers') {
        if(offset.dy<=MediaQuery.of(context).size.height/2){
          localCommand =
          "-i '$videoPath' -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]format=bgra,rotate=$_rotation:c=none:ow=rotw($_rotation):oh=roth($_rotation)[rotate];[rotate]scale=$wdata:-1[scale];[0:v][scale] overlay=x=${offset.dx * ratio}:y=${offset.dy * hratio}' -preset ultrafast '$outputPath'";
        }
        else
        {
          localCommand =
          "-i '$videoPath' -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]format=bgra,rotate=$_rotation:c=none:ow=rotw($_rotation):oh=roth($_rotation)[rotate];[rotate]scale=$wdata:-1[scale];[0:v][scale] overlay=x=${offset.dx * ratio}:y=${offset.dy * hratio+MediaQuery.of(context).size.height/8}' -preset ultrafast '$outputPath'";
        }
      }
      else {
        if(offset.dy<=MediaQuery.of(context).size.height/2){
          localCommand =
          "-i '$videoPath' -ignore_loop 0 -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]scale=$wdata:-1,setsar=1,rotate=$_rotation:c=black@0:ow=rotw($_rotation):oh=roth($_rotation) [rotate];[0:v][rotate] overlay=${offset.dx * ratio}:${offset.dy * hratio}:shortest=1' -codec:a copy -y '$outputPath'";
          //print('------------- $localCommand');
        }
        else
        {
          localCommand =
          "-i '$videoPath' -ignore_loop 0 -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]scale=$wdata:-1,setsar=1,rotate=$_rotation:c=black@0:ow=rotw($_rotation):oh=roth($_rotation) [rotate];[0:v][rotate] overlay=${offset.dx * ratio}:${offset.dy * hratio+MediaQuery.of(context).size.height/8}:shortest=1' -codec:a copy -y '$outputPath'";
          // print('------------- $localCommand');
        }
      }
    }
    else{
      if (type == 'Stickers') {
        if(offset.dy<=MediaQuery.of(context).size.height/2){
          localCommand =
          "-i '$videoPath' -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]format=bgra,rotate=$_rotation:c=none:ow=rotw($_rotation):oh=roth($_rotation)[rotate];[rotate]scale=$wdata:-1[scale];[0:v][scale] overlay=x=${offset.dx * ratio}:y=${offset.dy * hratio}' -preset ultrafast '$outputPath'";
        }
        else
        {
          localCommand =
          "-i '$videoPath' -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]format=bgra,rotate=$_rotation:c=none:ow=rotw($_rotation):oh=roth($_rotation)[rotate];[rotate]scale=$wdata:-1[scale];[0:v][scale] overlay=x=${offset.dx * ratio}:y=${offset.dy * hratio+MediaQuery.of(context).size.height/8}' -preset ultrafast '$outputPath'";
        }
      }
      else {
        if(offset.dy<=MediaQuery.of(context).size.height/2){
          localCommand =
          "-i '$videoPath' -ignore_loop 0 -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]scale=$wdata:-1,setsar=1,rotate=$_rotation:c=black@0:ow=rotw($_rotation):oh=roth($_rotation) [rotate];[0:v][rotate] overlay=${offset.dx * ratio}:${offset.dy * hratio}:shortest=1' -codec:a copy -y '$outputPath'";
          //print('------------- $localCommand');
        }
        else
        {
          localCommand =
          "-i '$videoPath' -ignore_loop 0 -i '$imgpath' -vcodec libx264 -crf 27 -filter_complex '[1:v]scale=$wdata:-1,setsar=1,rotate=$_rotation:c=black@0:ow=rotw($_rotation):oh=roth($_rotation) [rotate];[0:v][rotate] overlay=${offset.dx * ratio}:${offset.dy * hratio+MediaQuery.of(context).size.height/8}:shortest=1' -codec:a copy -y '$outputPath'";
          // print('------------- $localCommand');
        }
      }
    }
    await _flutterFFmpeg.execute(localCommand).then((value) {
      setState(() {
        loading = false;
      });
      print(" x $value} outputPath1 $outputPath");
    }).catchError((e) {
      print("error in 1 is $e");
    });
    return outputPath;
  }

  fetchData() async {
    matrix = Matrix4.identity();
    notifier = ValueNotifier(matrix);
    isCalled = true;
    _controller = VideoPlayerController.file(File(widget.result.files.single.path))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        _controller.play();
        _controller.setLooping(true);
        setState(() {
          loadedVideo = true;
        });
      });
    Future.delayed(const Duration(seconds: 5), () {
    });
    String data = await DefaultAssetBundle.of(context).loadString("assets/sticker_file.json");
    _listInfo = shareInfoModelFromJson(data);
    String gifData = await DefaultAssetBundle.of(context).loadString("assets/gif.json");
    _gifListInfo = gifStickerFromJson(gifData);
    print('ListInfo::$_listInfo');
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays ([SystemUiOverlay.bottom]);
    return SafeArea(
      child: Scaffold(
        body:
        !loading
            ? Container(
          color: Colors.black,
              child: Stack(
                children: [
                 Container(
                  child: LayoutBuilder(
                     builder: (ctx, constraints) {
                       var dx = offset.dx;
                       var dy =offset.dy;
                       matrix.leftTranslate(dx, dy);
                       // boxer = Boxer(Offset.zero & constraints.biggest, Rect.fromLTWH(0, 0, constraints.biggest.width, constraints.biggest.height));
                       return MatrixGestureDetector(
                         focalPointAlignment: Alignment.center,
                         shouldRotate: false,
                         shouldScale: true,
                         shouldTranslate: true,
                         onMatrixUpdate: (m, tm, sm, rm) {
                           matrix = MatrixGestureDetector.compose(m, tm, sm, null);
                           //     boxer.clamp(matrix);
                           notifier.value = matrix;
                           final val = MatrixGestureDetector.decomposeToValues(matrix);
                           _scale = val.scale;
                           offset = val.translation;
                           _rotation = val.rotation;
                           print('x::${val.translation.dx}y::${val.translation.dy}');
                           print('scale::$_scale,,rotation::$_rotation');
                         },
                         child: Stack(
                           children: [
                             loadedVideo
                                 ? Container(
                               height: _controller.value.size.height/_controller.value.size.width*MediaQuery.of(context).size.width,
                                 width: MediaQuery.of(context).size.width,
                                 child: VideoPlayer(_controller))
                                 : Container(),
                             Container(
                               width: double.infinity,
                               height: double.infinity,
                               alignment: Alignment.topLeft,
                               child: AnimatedBuilder(
                                 builder: (ctx, child) {
                                   return Transform(
                                     transform: matrix,
                                     child: Container(
                                       child:type=='Stickers'? Image.asset(
                                         _listInfo[selected].asset,
                                       ):Image.asset(
                                         _gifListInfo[selected].asset,
                                       ),
                                     ),
                                   );
                                 },
                                 animation: notifier,
                               ),
                             ),
                           ],
                         ),
                       );
                     },
                   ),
                 ),
                  Positioned(
                    bottom: 20,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          child: InkWell(
                            onTap: () async {
                              setState(() {
                                type = 'Stickers';
                              });
                              showModalBottomSheet(
                                  isDismissible: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
                                  ),
                                  context: context,
                                  //customBottomSheet
                                  builder: (context) => customBottomSheet(context, _listInfo));
                            },
                            child: Container(
                              height: 50,
                              width: 100,
                              decoration: BoxDecoration(
                                color: Colors.pink[700],
                                borderRadius: BorderRadius.all(Radius.circular(12)),
                              ),
                              child: Center(
                                child: Text(
                                  'Choose Sticker',
                                  style: TextStyle(color: Colors.white, fontSize: 14),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container
                          (
                          margin: EdgeInsets.all(20),

                          child: InkWell(
                            onTap: () async {
                              setState(() {
                                type = 'Gif';
                              });
                              showModalBottomSheet(
                                  isDismissible: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
                                  ),
                                  context: context,
                                  //customBottomSheet
                                  builder: (context) => customBottomSheet(context, _gifListInfo));
                            },
                            child: Container(
                              height: 50,
                              width: 100,
                              decoration: BoxDecoration(
                                color: Colors.pink[700],
                                borderRadius: BorderRadius.all(Radius.circular(12)),
                              ),
                              child: Center(
                                child: Text(
                                  'Choose Gif',
                                  style: TextStyle(color: Colors.white, fontSize: 14),
                                ),
                              ),
                            ),
                          ),

                        ),
                        
                        Container(
                          margin: EdgeInsets.all(20),
                          child: InkWell(
                            onTap: () async {
                              final outpath = await merge(context);
                              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => VideoApp(outpath)));
                            },
                            child: Container(
                              height: 50,
                              width: 70,
                              decoration: BoxDecoration(
                                color: Colors.pink[700],
                                borderRadius: BorderRadius.all(Radius.circular(12)),
                              ),
                              child: Center(
                                child: Text(
                                  'Next',
                                  style: TextStyle(color: Colors.white, fontSize: 16),
                                ),
                              ),
                            ),
                          ),

                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
            : Center(
                child: CircularProgressIndicator(
                  backgroundColor: Colors.pink[700],
                  semanticsLabel: 'Processing video please wait',
                ),
                widthFactor: 20,
                heightFactor: 20,
              ),
      ),
    );
  }

  Widget customBottomSheet(BuildContext context, List list) {
    return Container(
      height: 260,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
      ),
      child: Column(
        children: [
          Expanded(
            flex: 20,
            child: Center(
                child: Text(
              'Choose your sticker',
              style: TextStyle(color: Colors.white, fontSize: 21),
            )),
          ),
          Expanded(
            flex: 80,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      visibility = true;
                      selected = index;
                      offset = Offset(0,0);
                    });
                  Navigator.pop(context);
                    },
                  child: Container(
                    padding: EdgeInsets.all(12),
                    margin: EdgeInsets.all(12),
                    child: Image.asset(
                      list[index].asset,
                      width: 135,
                      height: 135,
                    ),
                  ),
                );
              },
              itemCount: list.length,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

class Boxer {
  final Rect bounds;
  final Rect src;
  Rect dst;

  Boxer(this.bounds, this.src);

  void clamp(Matrix4 m) {
    dst = MatrixUtils.transformRect(m, src);
    if (bounds.left <= dst.left && bounds.top <= dst.top && bounds.right >= dst.right && bounds.bottom >= dst.bottom) {
      // bounds contains dst
      return;
    }

    if (dst.width > bounds.width || dst.height > bounds.height) {
      Rect intersected = dst.intersect(bounds);
      FittedSizes fs = applyBoxFit(BoxFit.contain, dst.size, intersected.size);

      vector.Vector3 t = vector.Vector3.zero();
      intersected = Alignment.center.inscribe(fs.destination, intersected);
      if (dst.width > bounds.width)
        t.y = intersected.top;
      else
        t.x = intersected.left;

      var scale = fs.destination.width / src.width;
      vector.Vector3 s = vector.Vector3(scale, scale, 0);
      m.setFromTranslationRotationScale(t, vector.Quaternion.identity(), s);
      return;
    }

    if (dst.left < bounds.left) {
      m.leftTranslate(bounds.left - dst.left, 0.0);
    }
    if (dst.top < bounds.top) {
      m.leftTranslate(0.0, bounds.top - dst.top);
    }
    if (dst.right > bounds.right) {
      m.leftTranslate(bounds.right - dst.right, 0.0);
    }
    if (dst.bottom > bounds.bottom) {
      m.leftTranslate(0.0, bounds.bottom - dst.bottom);
    }
  }
}
