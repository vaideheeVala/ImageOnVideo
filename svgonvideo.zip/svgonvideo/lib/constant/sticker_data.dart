
import 'dart:convert';

List<ShareInfoModel> shareInfoModelFromJson(String str) => List<ShareInfoModel>.from(json.decode(str).map((x) => ShareInfoModel.fromJson(x)));
String shareInfoModelToJson(List<ShareInfoModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));
class ShareInfoModel {
  ShareInfoModel({
    this.name,
    this.asset,
    this.height,
    this.width,
  });

  String name;
  String asset;
  String height;
  String width;

  factory ShareInfoModel.fromJson(Map<String, dynamic> json) => ShareInfoModel(
    name: json["name"],
    asset: json["asset"],
    height: json["height"],
    width: json["height"],

  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "asset": asset,
    "height":height,
    "width":width,
  };
}
