// To parse this JSON data, do
//
//     final gifSticker = gifStickerFromJson(jsonString);

import 'dart:convert';

List<GifSticker> gifStickerFromJson(String str) => List<GifSticker>.from(json.decode(str).map((x) => GifSticker.fromJson(x)));

String gifStickerToJson(List<GifSticker> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class GifSticker {
  GifSticker({
    this.name,
    this.asset,
    this.height,
    this.width,
  });

  String name;
  String asset;
  String height;
  String width;

  factory GifSticker.fromJson(Map<String, dynamic> json) => GifSticker(
    name: json["name"],
    asset: json["asset"],
    height: json["height"],
    width: json["width"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "asset": asset,
    "height": height,
    "width": width,
  };
}
