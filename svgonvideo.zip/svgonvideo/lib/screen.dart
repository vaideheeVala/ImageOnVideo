import 'package:flutter/material.dart';

class ScreenDesign extends StatefulWidget {
  final Offset offset;

  ScreenDesign(this.offset);

  @override
  _ScreenDesignState createState() => _ScreenDesignState();
}

class _ScreenDesignState extends State<ScreenDesign> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            left: widget.offset.dx,
              top: widget.offset.dy,
              child: Container(
                height: 200,
            width: 200,
            color: Colors.yellow,
          )),
        ],
      ),
    );
  }
}
